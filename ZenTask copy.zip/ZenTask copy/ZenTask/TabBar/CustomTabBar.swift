//
//  CustomTabBar.swift
//  WeatherUIYt
//
//  Created by gokul-zstch1317 on 10/04/24.
//

import SwiftUI

enum Tab: String, CaseIterable {
    case house
    case bookmark
    case clock
    case person
}

struct CustomTabBar: View {
    
    @Binding var selectedTab: Tab
    private var fillImage: String {
        selectedTab.rawValue + ".fill"
    }
    
    private var tabColor: Color {
        switch selectedTab {
        case .house:
                .orange
        case .bookmark:
                .red
        case .clock:
                .teal
        case .person:
                .cyan
        }
    }
    
    var body: some View {
        VStack {
            HStack {
                ForEach(Tab.allCases, id: \.rawValue) { tab in
                    Spacer()
                    Image(systemName: selectedTab == tab ? fillImage : tab.rawValue)
                        .scaleEffect(selectedTab == tab ? 1.3 : 0.9)
                        .foregroundStyle(selectedTab == tab ? tabColor : .white)
                        .font(.system(size: 22))
                        .onTapGesture {
                            selectedTab = tab
                        }
                    Spacer()
                }
            }
            .frame(maxWidth: .infinity)
            .frame(height: 70)
            .background(Color.background1)
        }
    }
}

#Preview {
    CustomTabBar(selectedTab: .constant(.bookmark))
}


