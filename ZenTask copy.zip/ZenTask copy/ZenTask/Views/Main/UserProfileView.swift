//
//  UserDataView.swift
//  ZenTask
//
//  Created by gokul-zstch1317 on 23/04/24.
//

import SwiftUI

struct UserProfileView: View {
    
    @EnvironmentObject var viewModel: UsersViewModel
    @State private var isLogoutTapped: Bool = false
    @State private var isDeleteAccountTapped: Bool = false
    
    @Environment(\.presentationMode) var presentationMode
    
    init() {
        print("Hello from profile view")
    }
    
    
    var body: some View {
        NavigationStack{
            ZStack{
                Color.background1
                    .ignoresSafeArea()
                
                if let user = viewModel.currentUser {
                    List{
                        Section {
                            HStack {
                                Text(user.initials)
                                    .font(.title.bold())
                                    .kerning(2)
                                    .padding()
                                    .frame(width: 70, height: 70)
                                    .foregroundStyle(Color.white)
                                    .background(Color.gray)
                                    .clipShape(Circle())
                                
                                VStack(alignment: .leading, spacing: 8){
                                    Text(user.userName)
                                        .foregroundStyle(Color.black)
                                        .font(.system(size: 20, weight: .semibold))
                                    
                                    Text(user.email)
                                        .font(.footnote)
                                        .accentColor(.gray)
                                    
                                }
                            }
                        }
                        
                        Section("General"){
                            HStack{
                                ProfileRowView(imageName: "gear", title: "Version", tintColor: .gray)
                                
                                Spacer()
                                
                                Text("1.0.0")
                                    .foregroundStyle(Color.gray)
                                    .font(.footnote)
                            }
                            
                        }
                        
                        Section("Account") {
                            Button{
                                isLogoutTapped = true
                            }label: {
                                ProfileRowView(imageName: "arrow.right.circle.fill", title: "Logout", tintColor: .red)
                                    .font(.headline)
                                    .foregroundStyle(Color.black)
                            }
                            
                            Button{
                                isDeleteAccountTapped = true
                            }label: {
                                ProfileRowView(imageName: "xmark.circle.fill", title: "Delete Account", tintColor: .red)
                                    .font(.headline)
                                    .foregroundStyle(Color.black)
                            }
                        }
                        .alert("Do you really want to logout? ", isPresented: $isLogoutTapped) {
                            Button("No") {
                                
                            }
                            
                            Button("Yes") {
                                viewModel.logout()
                            }
                        }
                        .alert("Are you sure you want to delete your account ?", isPresented: $isDeleteAccountTapped, actions: {
                            Button("No") {
                                
                            }
                            
                            Button("Yes") {
                                viewModel.deleteAccount()
                            }
                        }) {
                            Text("If you delete your account you can't able to restore your details")
                        }
                    }
                }
            }
        }
    }
}

#Preview {
    UserProfileView()
}

struct ProfileRowView: View {
    @State var imageName: String
    @State var title: String
    @State var tintColor: Color
    
    var body: some View {
        HStack(spacing: 10){
            Image(systemName: imageName)
                .imageScale(.medium)
                .foregroundStyle(tintColor)
            
            Text(title)
                .font(.subheadline)
            
            
        }
    }
}
