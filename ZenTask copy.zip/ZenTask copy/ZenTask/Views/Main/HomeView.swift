//
//  HomeView.swift
//  WeatherUIYt
//
//  Created by gokul-zstch1317 on 09/04/24.
//

import SwiftUI

struct HomeView: View {
    
    @State private var todoListView: TodoListView
    @State private var selectedTab: Tab = .house
    @EnvironmentObject var viewModel: UsersViewModel
    
    init() {
        UITabBar.appearance().isHidden = true
        todoListView = TodoListView()
    }
    var body: some View {
        ZStack {
            Color.background1
                .ignoresSafeArea()
            
            VStack (spacing: 0){
                    TabView {
                        switch selectedTab {
                        case .house:
                            todoListView
                                .onAppear {
                                    self.todoListView = TodoListView()
                                }
                                .ignoresSafeArea()
                        case .bookmark:
                            VStack{
                                Text("Hello 1")
                            }
                        case .clock:
                            VStack{
                                Text("Hello 2")
                            }
                        case .person:
                            UserProfileView()
                                .ignoresSafeArea()
                        }
                    }
                    .tabViewStyle(DefaultTabViewStyle())
                    .frame(maxHeight: .infinity)
                    
                CustomTabBar(selectedTab: $selectedTab)
            }
            .ignoresSafeArea()
        }
    }
}

#Preview {
    HomeView()
}
