//
//  UsersViewModel.swift
//  ZenTask
//
//  Created by gokul-zstch1317 on 25/04/24.
//

import Foundation
import Firebase
import FirebaseFirestoreSwift

@MainActor
class UsersViewModel: ObservableObject {
    
    @Published var userSession: FirebaseAuth.User?
    @Published var currentUser: Users?
    
    init() {
        self.userSession = Auth.auth().currentUser
        
        Task {
            await fetchUser(completeion: { sucess in
                switch sucess {
                case true:
                    print("User data fetched sucessfully")
                case false:
                    print("Unable to fetch user data")
                }
            })
        }
    }
    
    func login(with UserName: String, password: String) async throws {
        do {
            let resultUser = try await Auth.auth().signIn(withEmail: UserName, password: password)
            self.userSession = resultUser.user
            await fetchUser(completeion: { resultBool in
                switch resultBool {
                case true:
                    print("User is found and logged in")
                    
                case false:
                    print("User cannot not be founded failed to login")
                    
                }
            })
        }
    }
    
//    func signUP(with userName: String, password: String, email: String) async throws {
//        do {
//            
//            let result = try await Auth.auth().createUser(withEmail: email, password: password)
//            self.userSession = result.user
//            var user = Users(id: result.user.uid, userName: userName, email: email)
//            user.setPassword(password: password)
//            let encodedUser = try Firestore.Encoder().encode(user)
//            try await Firestore.firestore().collection("Users").document(result.user.uid).setData(encodedUser)
//            await fetchUser(completeion: { sucess in
//            })
//        } catch {
//            print("Failed to create user \(error.localizedDescription)")
//            return
//        }
//        
//    }
    
    func signUP(with userName: String, password: String, email: String) async throws {
        do {
            let result = try await Auth.auth().createUser(withEmail: email, password: password)
            self.userSession = result.user
            var user = Users(id: result.user.uid, userName: userName, email: email)
            user.setPassword(password: password)
            let encodedUser = try Firestore.Encoder().encode(user)
            try await Firestore.firestore().collection("Users").document(result.user.uid).setData(encodedUser)
            await fetchUser(completeion: { success in
                switch success {
                case true:
                    print("User is stored and signed in")
                    
                case false:
                    print("User cannot not be stored failed to sign")
                    
                }
            })
        }
    }

    
    func logout() {
        
        do {
            try Auth.auth().signOut()
            self.userSession = nil
            self.currentUser = nil
        } catch {
            print("Error while signing out the user \(error.localizedDescription)")
        }
    }
    
    func deleteAccount() {
        do {
            Auth.auth().currentUser?.delete()
            self.userSession = nil
            self.currentUser = nil
        }
    }
    
    func fetchUser(completeion: @escaping (Bool) -> Void) async {
        guard let uid = Auth.auth().currentUser?.uid else {
            completeion(false)
            return
        }
        
        
        do {
            let snapshot = try await Firestore.firestore().collection("Users").document(uid).getDocument()
            
            if snapshot.exists {
                if let userData = try? snapshot.data(as: Users.self) {
//                    print("User data fetched successfully: \(userData)")
                    self.currentUser = userData
                    completeion(true)
                } else {
                    print("Failed to decode user data")
                    completeion(false)
                }
            } else {
                print("User document does not exist")
                completeion(false)
            }
        } catch {
            print("Error fetching user: \(error.localizedDescription)")
            completeion(false)
        }
    }

}
