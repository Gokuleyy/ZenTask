//
//  TodoListViewController.swift
//  ZenTask
//
//  Created by gokul-zstch1317 on 15/04/24.
//

import UIKit
import SwiftUI

class TodoListViewController: UIViewController {
    
    static let taskVC = AddTaskViewController()
    
    var viewModel: UsersViewModel?
    static var isDataFetched = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addView()
        addConstraints()
        setUpCollectionView()
        setUpTableView()
        if !TodoListViewController.isDataFetched {
            Task{
                do {
                    await fetchDataAndUpdateUI()
                }
            }
        }
        else {
            DispatchQueue.main.async {
                self.updateUI()
            }
        }
        
    }
    
    private func updateUI() {
        print("Update UI called")
        if let viewModel = viewModel?.currentUser {
            print("User data available")
            withAnimation {
                userNameLabel.text = viewModel.userName
            }
        } else {
            print("User data not available yet")
        }
    }
    
    private var collectionView: UICollectionView?
    private var optionsArray: [String] = ["All Tasks","Completed", "Incompleted", "High Priority", "Medium Priority", "Low Priority"]
    private var tableView: UITableView = UITableView()
    
    
    private let activityIndicator: UIActivityIndicatorView = {
        let indicator = UIActivityIndicatorView(style: .large)
        indicator.color = .gray
        indicator.hidesWhenStopped = true
        return indicator
    }()
    
    private func showLoadingIndicator() {
        view.addSubview(activityIndicator)
        activityIndicator.center = view.center
        activityIndicator.startAnimating()
    }
    
    private func hideLoadingIndicator() {
        activityIndicator.stopAnimating()
        activityIndicator.removeFromSuperview()
    }
    
    func fetchDataAndUpdateUI() async {
        showLoadingIndicator()
        
        await viewModel?.fetchUser { [weak self] success in
            guard let self = self else { return }
            
            self.hideLoadingIndicator()
            
            if success {
                DispatchQueue.main.async {
                    self.updateUI()
                }
                TodoListViewController.isDataFetched = true
            } else {
                print("Error fetching user data")
                return
            }
        }
    }
    
    private let headerView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.clipsToBounds = true
        view.translatesAutoresizingMaskIntoConstraints = false
        view.frame = CGRect(x: 0, y: 0, width: 300, height: 300)
        view.layer.cornerRadius = 0
        return view
    }()
    
    private let headerImageProfile: UIImageView = {
        let imageView = UIImageView()
        imageView.image = .facebookLogo
        imageView.clipsToBounds = true
        imageView.translatesAutoresizingMaskIntoConstraints = false
//        imageView.layer.borderWidth = 2
//        imageView.layer.borderColor = UIColor.black.cgColor
//        imageView.layer.cornerRadius = 10
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    private let welcomeMessageLabel: UILabel = {
        let label = UILabel()
        label.text = "Welcome Back"
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont.systemFont(ofSize: 18, weight: .light)
        return label
    }()
    
    let userNameLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont.systemFont(ofSize: 28, weight: .medium)
        return label
    }()
    
    private let addIconButton: ResizableImageButton = {
        let button = ResizableImageButton(image: UIImage(systemName: "plus"))
        button.setImage(UIImage(systemName: "plus"), for: .normal)
        button.tintColor = .gray
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(nil, action: #selector(TodoListViewController.AddIconButtonTapped), for: .touchDown)
        return button
    }()
    
    func addView(){
        
        //MARK: Adding subview for the main views
        view.addSubview(headerView)
        
        //MARK: Adding subview for the header view
        headerView.addSubview(headerImageProfile)
        headerView.addSubview(welcomeMessageLabel)
        headerView.addSubview(userNameLabel)
        headerView.addSubview(addIconButton)
        
    }
    
    func addConstraints(){
        NSLayoutConstraint.activate([
            
            //MARK: Header View where the user details and calender are available
            headerView.topAnchor.constraint(equalTo: self.view.topAnchor),
            headerView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor),
            headerView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor),
            headerView.heightAnchor.constraint(equalToConstant: 200),
            
                //MARK: Contraints for elements inside the header view
            headerImageProfile.widthAnchor.constraint(equalToConstant: 50),
            headerImageProfile.heightAnchor.constraint(equalToConstant: 50),
            headerImageProfile.leadingAnchor.constraint(equalTo: headerView.leadingAnchor, constant: 20),
            headerImageProfile.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor, constant: -20),
            
            welcomeMessageLabel.centerYAnchor.constraint(equalTo: headerImageProfile.centerYAnchor, constant: -15),
            welcomeMessageLabel.leadingAnchor.constraint(equalTo: headerImageProfile.trailingAnchor, constant: 10),
            
            userNameLabel.centerYAnchor.constraint(equalTo: headerImageProfile.centerYAnchor, constant: 15),
            userNameLabel.leadingAnchor.constraint(equalTo: welcomeMessageLabel.leadingAnchor),
            
            addIconButton.centerYAnchor.constraint(equalTo: headerImageProfile.centerYAnchor),
            addIconButton.trailingAnchor.constraint(equalTo: headerView.trailingAnchor, constant: -20),
            addIconButton.widthAnchor.constraint(equalToConstant: 40),
            addIconButton.heightAnchor.constraint(equalToConstant:40)
            
        ])
    }
    @objc func AddIconButtonTapped(){
        TodoListViewController.taskVC.modalPresentationStyle = .formSheet
        present(TodoListViewController.taskVC, animated: true)
    }
}

//MARK: COLLECTIONVIEW EXTENSION

extension TodoListViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func setUpCollectionView(){
        collectionView = UICollectionView(frame: .zero, collectionViewLayout: headerOptionsCompositionalLayout())
        guard let collectionView = collectionView else { return }
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        collectionView.register(CollectionViewOptionsCell.self, forCellWithReuseIdentifier: CollectionViewOptionsCell.reuseIdentifier)
        collectionView.backgroundColor = .clear
        view.addSubview(collectionView)
        
        NSLayoutConstraint.activate([
            collectionView.bottomAnchor.constraint(equalTo: headerView.bottomAnchor, constant: -5),
            collectionView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor),
            collectionView.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return optionsArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CollectionViewOptionsCell.reuseIdentifier, for: indexPath) as! CollectionViewOptionsCell
        cell.setLabelHeading(heading: optionsArray[indexPath.row])
        cell.backgroundColor = .gray
        cell.layer.cornerRadius = 20
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CollectionViewOptionsCell.reuseIdentifier, for: indexPath) as! CollectionViewOptionsCell
        cell.selectedCell = optionsArray[indexPath.item]
        cell.didSelectCell(selectedCell: optionsArray[indexPath.row])
        print(cell.selectedCell)
    }
    
    func headerOptionsCompositionalLayout() -> UICollectionViewCompositionalLayout{
        
        UICollectionViewCompositionalLayout { sectionIndex, LayoutEnvironment in
            switch sectionIndex {
            case 0:
                let item = NSCollectionLayoutItem(layoutSize: .init(widthDimension: .fractionalWidth(1/3), heightDimension: .fractionalHeight(1)))
                item.contentInsets = NSDirectionalEdgeInsets(.init(top: 0, leading: 10, bottom: 0, trailing: 10))
                let group = NSCollectionLayoutGroup.horizontal(layoutSize: .init(widthDimension: .fractionalWidth(1.3), heightDimension: .fractionalHeight(0.8)), subitems: [item])
                let section = NSCollectionLayoutSection(group: group)
                section.orthogonalScrollingBehavior = .continuous
                return section
            default:
                return nil
            }
        }
    }
    
    
}

//MARK: TABLE VIEW EXTENSION

extension TodoListViewController: UITableViewDelegate, UITableViewDataSource {
    
    func setUpTableView() {
        tableView = UITableView(frame: .zero, style: .plain)
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(TableViewTasksCell.self, forCellReuseIdentifier: TableViewTasksCell.reuseIdentifier)
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.rowHeight = 100
        tableView.showsVerticalScrollIndicator = false
        view.addSubview(tableView)
        
        //MARK: Set contrainsts for TableView
        
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: headerView.bottomAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel?.currentUser?.tasks?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: TableViewTasksCell.reuseIdentifier, for: indexPath) as! TableViewTasksCell
        cell.setLabel(text: "1")
        return cell
    }
    
    
}

class ResizableImageButton: UIButton {
    
    private let padding: CGFloat = 7 // Adjust the padding as needed
    
    override func imageRect(forContentRect contentRect: CGRect) -> CGRect {
        let insetRect = contentRect.insetBy(dx: padding, dy: padding)
        return insetRect
    }
    
    init(image: UIImage?) {
        super.init(frame: .zero)
        setImage(image, for: .normal)
        imageView?.contentMode = .scaleAspectFit
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

