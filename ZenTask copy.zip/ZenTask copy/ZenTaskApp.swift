//
//  ZenTaskApp.swift
//  ZenTask
//
//  Created by gokul-zstch1317 on 15/04/24.
//

import SwiftUI
import Firebase

@main
struct ZenTaskApp: App {
    
    @StateObject private var viewModel = UsersViewModel()
    
    init() {
        FirebaseApp.configure()
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(viewModel)
        }
    }
}


