//
//  LoginPageView.swift
//  ZenTask
//
//  Created by gokul-zstch1317 on 12/04/24.
//

import SwiftUI

struct LoginPageView: View {
    
    @State var email: String = ""
    @State private var password: String = ""
    @State private var errorMessage: String = ""
    @State var isViewPassword: Bool = false
    @EnvironmentObject var viewModel: UsersViewModel
    @State private var showRedError: Bool = false
    @State private var isKeyboardVisible: Bool  = false
    @State private var offset: CGFloat = 0
    @FocusState private var isUserEmailFocused: Bool
    @State private var isLoginSucessful: Bool = false
    @Environment(\.presentationMode) private var presentationMode
    @State var isPresentedFromSignUpPage: Bool
    @State var isLoading: Bool = false
    @State private var showEmailAlert: Bool = true
    @State private var isShowingProgress = false
    
    private var isEmailEmpty: Bool { return email.isEmpty }
    private var isPasswordEmpty: Bool { return password.isEmpty }
    
    
    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(colors: [Color.background2, Color.weatherWidgetBackground1], startPoint: .topTrailing, endPoint: .bottomLeading)
                    .ignoresSafeArea()
                
                
                GeometryReader { geometry in
                    
                    ScrollView{
                        
                        VStack(alignment: .center) {
                            
                            HStack {
                                
                                if isPresentedFromSignUpPage {
                                    
                                    Image(systemName: "arrow.left")
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .foregroundStyle(.probabilityText)
                                        .frame(width: 30, height: 30)
                                        .onTapGesture {
                                            self.presentationMode.wrappedValue.dismiss()
                                        }
                                } else {
                                    
                                    Image(.titleLogo)
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .frame(width: 70, height: 70)
                                }
                                
                                Spacer()
                                
                                if isPresentedFromSignUpPage {
                                    
                                    Image(.titleLogo)
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .frame(width: 70, height: 70)
                                } else {
                                    Image(systemName: "xmark.circle.fill")
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .foregroundStyle(.logoColor2)
                                        .frame(width: 30, height: 30)
                                        .onTapGesture {
                                            self.presentationMode.wrappedValue.dismiss()
                                        }
                                }
                                
                            }
                            .padding()
                            .frame(width: geometry.size.width, height: geometry.size.height * 0.2)
                            
                            Spacer()
                            
                            VStack(alignment: .center, spacing: 0) {
                                
                                HStack {
                                    Text("Hi ! \nWelcome Back")
                                        .foregroundStyle(Color.logoColor1)
                                        .font(.system(.title3, design: .serif))
                                        .fontWeight(.bold)
                                        .kerning(1)
                                    
                                    Spacer()
                                }
                                .frame(width: geometry.size.width * 0.8)
                                
                                 Spacer()
                                
                                VStack {
                                    Spacer()
                                    
                                    CustomTextField(text: $email, isPassword: false, placeholder: "Email", size: geometry.size, focusedField: _isUserEmailFocused)
                                    .padding()
                                    .frame(width: geometry.size.width * 0.8, height: geometry.size.height * 0.15)
                                    .onAppear {
                                        isUserEmailFocused = true
                                    }
                                    .onChange(of: isUserEmailFocused) { focused in
                                        if !focused {
                                            showEmailAlert = RegexFoundation.checkRegexPattern(pattern: RegexFoundation.emailRegex, stringToCheck: email)
                                        }
                                    }
                                    .overlay(
                                        
                                        Image(systemName: isEmailEmpty ? "" : "xmark.circle.fill")
                                            .foregroundStyle(.white)
                                            .padding(.bottom, 10)
                                            .onTapGesture {
                                                self.email = ""
                                            },
                                        alignment: .trailing
                                    )
                                    
                                    if !showEmailAlert {
                                        
                                        HStack {
                                            Image(systemName: "xmark.circle.fill")
                                                .foregroundStyle(.logoColor1)
                                                
                                            Text("Please enter a valid email address")
                                                .font(.system(.caption, design: .rounded))
                                                .foregroundStyle(.logoColor1)
                                            
                                            Spacer()
                                        }
                                        .frame(width: geometry.size.width * 0.8, height: geometry.size.height * 0)
                                    }
                                    
                                    Spacer()
                                    
                                    CustomTextField(text: $password, isPassword: !isViewPassword, placeholder: "Password", size: geometry.size)
                                    .padding()
                                    .frame(width: geometry.size.width * 0.8, height: geometry.size.height * 0.15)
                                    .overlay (
                                        Image(systemName: isViewPassword ? "eye" : "eye.slash")
                                            .foregroundStyle(.white)
                                            .padding(.bottom, 10)
                                            .onTapGesture {
                                                isViewPassword.toggle()
                                            },
                                        alignment: .trailing
                                    )
                                    
                                    if !isPasswordEmpty {
                                        PasswordField1(password: $password)
                                            .padding()
                                            .frame(width: geometry.size.width * 0.9, height: geometry.size.height * 0.02)
                                    }
                                    
                                    Spacer()
                                    
                                    
                                    VStack(spacing: 20) {
                                        
                                        if showRedError {
                                            HStack {
                                                Image(systemName: "xmark.circle.fill")
                                                    .foregroundStyle(.logoColor1)
                                                    
                                                Text(self.errorMessage)
                                                    .font(.system(.callout, design: .rounded))
                                                    .foregroundStyle(.logoColor1)
                                            }
                                            .frame(width: geometry.size.width * 0.8, height: geometry.size.height * 0.02)
                                        }
                                        
                                        Button {
                                            if isValidField {
                                                Task {
                                                    do {
                                                        try await viewModel.login(with: email, password: password)
                                                        self.presentationMode.wrappedValue.dismiss()
                                                        
                                                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                                                            isLoginSucessful = true
                                                        }
                                                    } catch {
                                                        self.errorMessage = "Invalid user credentials! try SignUp"
                                                        showRedError = true
                                                       
                                                    }
                                                }
                                            } else {
                                                self.errorMessage = "Please check all the fields"
                                                showRedError = true
                                                
                                            }
                                            
                                        }label: {
                                            CustomisedButton(buttonTitle: "Login", size: geometry.size)
                                        }
                                        .buttonStyle(CustomButtonStyle(backgroundColor: .probabilityText))
                                        
                                        HStack {
                                            Text("Don't have an account? ")
                                                .font(.system(.callout, design: .serif))
                                                .foregroundStyle(.white)
                                                .fontWeight(.ultraLight)
                                            
                                            if !isPresentedFromSignUpPage {
                                                
                                                NavigationLink(destination: SignUpPage(isPresentedFromLoginView: true)) {
                                                    Text("Sign Up")
                                                        .font(.system(.title3, design: .serif))
                                                        .underline()
                                                        .foregroundStyle(Color.probabilityText)
                                                        .fontWeight(.semibold)
                                                    
                                                }
                                            } else {
                                                Text("Sign Up")
                                                    .font(.system(.title3, design: .serif))
                                                    .underline()
                                                    .foregroundStyle(Color.probabilityText)
                                                    .fontWeight(.semibold)
                                                    .onTapGesture {
                                                        self.presentationMode.wrappedValue.dismiss()
                                                    }
                                            }
                                            
                                            
                                        }
                                        .frame(width: geometry.size.width * 0.8)
                                    }
                                    .frame(width: geometry.size.width, height: geometry.size.height * 0.3)
                                    
                                    Spacer()
                                }
                                    
                                
                            }
                            .padding()
                            .frame(width: geometry.size.width, height: geometry.size.height * 0.8)
                            .onAppear {
                                NotificationCenter.default.addObserver(forName: UIResponder.keyboardWillShowNotification, object: nil, queue: .main) { notification in
                                    withAnimation {
                                        self.isKeyboardVisible = true
                                    }
                                }
                                
                                NotificationCenter.default.addObserver(forName: UIResponder.keyboardWillHideNotification, object: nil, queue: .main) { _ in
                                    withAnimation {
                                        self.isKeyboardVisible = false
                                    }
                                }
                            }
                        }
                        .padding()
                        .frame(width: geometry.size.width, height: geometry.size.height)
                        
                    }
                    .scrollDisabled(!isKeyboardVisible)
                    
                    
                }
                
            }
            .gesture(
                TapGesture()
                    .onEnded { _ in
                        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
                    }
            )
            .fullScreenCover(isPresented: $isLoginSucessful) {
                
                if self.presentationMode.wrappedValue.isPresented {
                    ProgressView()
                } else {
                    HomeView()
                }
            }
        }
        .navigationBarBackButtonHidden(true)
    }
}
    
    
extension LoginPageView: AuthenticationOnRegexForTheUsersInputs {
    var isValidField: Bool {
        return !email.isEmpty &&
        !password.isEmpty &&
        password.count >= 6 &&
        RegexFoundation.checkRegexPattern(pattern: RegexFoundation.emailRegex, stringToCheck: email) &&
        RegexFoundation.checkRegexPattern(pattern: RegexFoundation.passwordRegex, stringToCheck: password)
    }
}
    
#Preview {
    LoginPageView(isPresentedFromSignUpPage: false)
}
    
