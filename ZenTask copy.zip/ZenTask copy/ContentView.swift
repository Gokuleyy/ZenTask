//
//  ContentView.swift
//  WeatherUIYt
//
//  Created by gokul-zstch1317 on 09/04/24.
//

import SwiftUI

struct ContentView: View {
    @EnvironmentObject var viewModel: UsersViewModel
    var body: some View {
        Group {
            if viewModel.userSession != nil {
                HomeView()
            } else {
                StartingPage()
            }
        }
    }
}

#Preview {
    ContentView()
}
