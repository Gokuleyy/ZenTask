//
//  RegexFoundation.swift
//  ZenTask
//
//  Created by gokul-zstch1317 on 29/04/24.
//

import Foundation
import CryptoKit


class RegexFoundation {
    
    static let emailRegex = "^[a-zA-Z0-9]+[a-zA-Z0-9_.-]+@[a-zA-Z]+\\.[a-z]{2,3}$"
    static let passwordRegex = "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@#$%^&+=*!-])[A-Za-z0-9@#$%^&+=*!-]{6,15}$"
    
    static func checkRegexPattern(pattern: String, stringToCheck: String) -> Bool {
        do {
            let regex = try NSRegularExpression(pattern: pattern, options: [])
            let range = NSRange(location: 0, length: stringToCheck.count)
            
            return regex.firstMatch(in: stringToCheck, options: [], range: range) != nil
        }
        catch {
            
            return false
        }
    }
    
    init(){
    }
    
    static func hashPassword(password: String) -> String? {
        let passwordData = password.data(using: .utf8)!
        
        let hashedData = SHA256.hash(data: passwordData)
        let hashedPasswordString = hashedData.compactMap { String(format: "%02x", $0)}.joined()
        
        return hashedPasswordString
    }
}

protocol AuthenticationOnRegexForTheUsersInputs {
    var isValidField: Bool { get }
}
