//
//  LoginPage.swift
//  ZenTask
//
//  Created by gokul-zstch1317 on 11/04/24.
//

import SwiftUI

struct StartingPage: View {
    
    @State private var isLoginTapped: Bool = false
    @State private var isSignUpTapped: Bool = false
    
    @State private var isPressed = false
    
    var body: some View {
        ZStack {
            LinearGradient(colors: [Color.background1, Color.forecastCardBackground], startPoint: .topTrailing, endPoint: .bottomLeading)
                .ignoresSafeArea()
            
            GeometryReader { geometry in
                VStack(alignment: .center, spacing: 20) {
                    
                    Spacer()
                    
                    VStack(spacing: 10) {
                        
                        Image(.titleLogo)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 80, height: 80)
                        
                        Text("ZENTASK")
                            .foregroundStyle(Color.white)
                            .font(.system(.title, design: .serif)).bold()
                            .kerning(2)
                            
                        
                        Text("Performance Pinnacle")
                            .foregroundStyle(Color.white)
                            .font(.callout.smallCaps())
                    }
                    .frame(width: geometry.size.width, height: geometry.size.height * 0.5)
                    
                    VStack(spacing: 20) {
                        Button(action: {
                            isLoginTapped = true
                        }) {
                            Text("Login")
                                .font(.system(.title2, design: .serif))
                                .fontWeight(.semibold)
                                .foregroundStyle(Color.background1)
                                .frame(width: geometry.size.width * 0.6, height: 50)
                                .background(Color.probabilityText)
                                .clipShape(RoundedRectangle(cornerRadius: 10))
                        }
                        .buttonStyle(CustomButtonStyle(backgroundColor: .clear))
                        
                        Button(action: {
                            isSignUpTapped = true
                        }) {
                            Text("Sign Up")
                                .font(.system(.title2, design: .serif))
                                .fontWeight(.semibold)
                                .foregroundStyle(Color.probabilityText)
                                .frame(width: geometry.size.width * 0.6, height: 50)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 15)
                                        .stroke(Color.probabilityText, lineWidth: 3)
                                )
                            
                            
                        }
                        .buttonStyle(CustomButtonStyle(backgroundColor: .background1))
                    }
                    .frame(width: geometry.size.width, height: geometry.size.height * 0.5)
                    
                    Spacer()
                    
                }
                .frame(width: geometry.size.width, height: geometry.size.height)
            }
        }
        .sheet(isPresented: $isLoginTapped) {
            LoginPageView(isPresentedFromSignUpPage: false)
        }
        .sheet(isPresented: $isSignUpTapped) {
            SignUpPage(isPresentedFromLoginView: false)
        }
    }
}

struct LogoView: View {
    var body: some View {
        Image(.titleLogo)
            .resizable()
            .scaledToFit()
    }
}


#Preview {
    StartingPage()
}


