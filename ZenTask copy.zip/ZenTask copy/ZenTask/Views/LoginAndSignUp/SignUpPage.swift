//
//  SignUpPage.swift
//  ZenTask
//
//  Created by gokul-zstch1317 on 12/04/24.
//

import SwiftUI

struct SignUpPage: View {
    
    @State private var isKeyboardVisible: Bool  = false
    @State private var showHomePage: Bool = false
    @State var isViewPassword: Bool = false
    @State private var showRedError: Bool = false
    @State private var showEmailAlert: Bool = true
    @State var userName: String = ""
    @State var email: String = ""
    @State private var password: String = ""
    @State private var confirmPassword: String = ""
    @State private var errorMessage: String = ""
    @Environment (\.presentationMode) var presentationMode
    @EnvironmentObject var viewModel: UsersViewModel
    @State var isPresentedFromLoginView: Bool
    @FocusState private var isUserNameFocused: Bool
    @FocusState private var isEmailFocused: Bool
    
    
    private var isUserNameEmpty: Bool { return userName.isEmpty }
    private var isEmailEmpty: Bool { return email.isEmpty }
    private var isConfirmPasswordEmpty: Bool { return confirmPassword.isEmpty }
    private var isPasswordEqualsConfirmPassword: Bool { password == confirmPassword }
    
    var body: some View {
        
        NavigationView {
            ZStack{
                LinearGradient(colors: [Color.background2, Color.weatherWidgetBackground1], startPoint: .topTrailing, endPoint: .bottomLeading)
                    .ignoresSafeArea()
                
                GeometryReader { geometry in
                    
                    ScrollView {
                        
                        VStack(alignment: .center, spacing: 0) {
                            HStack {
                                
                                if isPresentedFromLoginView {
                                    
                                    Image(systemName: "arrow.left")
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .foregroundStyle(.probabilityText)
                                        .frame(width: 30, height: 30)
                                        .onTapGesture {
                                            self.presentationMode.wrappedValue.dismiss()
                                        }
                                } else {
                                    
                                    Image(.titleLogo)
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .frame(width: 70, height: 70)
                                }
                                
                                Spacer()
                                
                                if isPresentedFromLoginView {
                                    
                                    Image(.titleLogo)
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .frame(width: 70, height: 70)
                                } else {
                                    Image(systemName: "xmark.circle.fill")
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .foregroundStyle(.logoColor2)
                                        .frame(width: 30, height: 30)
                                        .onTapGesture {
                                            self.presentationMode.wrappedValue.dismiss()
                                        }
                                }
                                
                            }
                            .padding()
                            .frame(width: geometry.size.width, height: geometry.size.height * 0.1)
                            
                            VStack(spacing: 0) {
                                
                                HStack {
                                    Text("Create ! \nNew Account")
                                        .foregroundStyle(Color.logoColor1)
                                        .font(.system(.headline, design: .serif))
                                        .fontWeight(.bold)
                                        .kerning(1)
                                    
                                    Spacer()
                                }
                                .frame(width: geometry.size.width * 0.8)
                                
                                Spacer()
                                
                                VStack(spacing: 0) {
                                    
                                    Spacer()
                                    
                                    CustomTextField(text: $userName, isPassword: false, placeholder: "Username", size: geometry.size, focusedField: _isUserNameFocused)
                                        .padding()
                                        .frame(width: geometry.size.width * 0.8, height: geometry.size.height * 0.1)
                                        .onAppear {
                                           isUserNameFocused = true
                                        }
                                        .overlay(
                                            
                                            Image(systemName: isUserNameEmpty ? "" : "xmark.circle.fill")
                                                .foregroundStyle(.white)
                                                .padding(.bottom, 10)
                                                .onTapGesture {
                                                    self.userName = ""
                                                },
                                            alignment: .trailing
                                        )
                                    
                                    Spacer()
                                    
                                    CustomTextField(text: $email, isPassword: false, placeholder: "Email", size: geometry.size)
                                        .padding()
                                        .frame(width: geometry.size.width * 0.8, height: geometry.size.height * 0.1)
                                        .focused($isEmailFocused)
                                        .onChange(of: isEmailFocused) { focused in
                                            if !focused {
                                                showEmailAlert = RegexFoundation.checkRegexPattern(pattern: RegexFoundation.emailRegex, stringToCheck: email)
                                            }
                                        }
                                        .overlay(
                                            
                                            Image(systemName: isEmailEmpty ? "" : "xmark.circle.fill")
                                                .foregroundStyle(.white)
                                                .padding(.bottom, 10)
                                                .onTapGesture {
                                                    self.email = ""
                                                },
                                            alignment: .trailing
                                        )
                                    
                                    if !showEmailAlert {
                                        
                                        HStack {
                                            Image(systemName: "xmark.circle.fill")
                                                .foregroundStyle(.logoColor1)
                                                
                                            Text("Please enter a valid email address")
                                                .font(.system(.caption, design: .rounded))
                                                .foregroundStyle(.logoColor1)
                                            
                                            Spacer()
                                        }
                                        .frame(width: geometry.size.width * 0.8, height: geometry.size.height * 0.02)
                                    }
                                    
                                    Spacer()
                                    
                                    
                                    
                                    CustomTextField(text: $password, isPassword: !isViewPassword, placeholder: "Password", size: geometry.size)
                                        .padding()
                                        .frame(width: geometry.size.width * 0.8, height: geometry.size.height * 0.1)
                                        .overlay (
                                            Image(systemName: isViewPassword ? "eye" : "eye.slash")
                                                .foregroundStyle(.white)
                                                .padding(.bottom, 10)
                                                .onTapGesture {
                                                    isViewPassword.toggle()
                                                },
                                            alignment: .trailing
                                        )
                                    if !password.isEmpty {
                                        PasswordField1(password: $password)
                                            .padding()
                                            .frame(width: geometry.size.width * 0.9, height: geometry.size.height * 0.02)
                                    }
                                    
                                    Spacer()
                                    
                                    CustomTextField(text: $confirmPassword, isPassword: false, placeholder: "Confirm-password", size: geometry.size)
                                        .padding()
                                        .frame(width: geometry.size.width * 0.8, height: geometry.size.height * 0.1)
                                        .overlay(
                                            
                                            Image(systemName: isConfirmPasswordEmpty ? "" : "xmark.circle.fill")
                                                .foregroundStyle(.white)
                                                .padding(.bottom, 10)
                                                .onTapGesture {
                                                    self.confirmPassword = ""
                                                },
                                            alignment: .trailing
                                        )
                                    
                                    
                                    if !isConfirmPasswordEmpty {
                                        if !isPasswordEqualsConfirmPassword {
                                            HStack {
                                                Image(systemName: "xmark.circle.fill")
                                                    .foregroundStyle(.logoColor1)
                                                    
                                                Text("Passwords doesn't matches")
                                                    .font(.system(.caption, design: .rounded))
                                                    .foregroundStyle(.logoColor1)
                                                
                                                Spacer()
                                            }
                                            .frame(width: geometry.size.width * 0.8, height: geometry.size.height * 0.02)
                                        }
                                    }
                                    
                                    Spacer()
                                    
                                    VStack(spacing: 20) {
                                        
                                        if showRedError {
                                            HStack {
                                                Image(systemName: "xmark.circle.fill")
                                                    .foregroundStyle(.logoColor1)
                                                    
                                                Text(self.errorMessage)
                                                    .font(.system(.callout, design: .rounded))
                                                    .foregroundStyle(.logoColor1)
                                            }
                                            .frame(width: geometry.size.width * 0.8, height: geometry.size.height * 0.02)
                                        }
                                        
                                        Button {
                                            if isValidField {
                                                Task {
                                                    do {
                                                        try await viewModel.signUP(with: userName, password: password, email: email)
                                                        showHomePage = true
                                                    } catch {
                                                        showRedError = true
                                                        self.errorMessage = "The email is already in use! try Login"
                                                        print(error.localizedDescription)
                                                    }
                                                }
                                            } else {
                                                showRedError = true
                                                self.errorMessage = "Please check all the fields"
                                            }
                                            
                                        }label: {
                                            CustomisedButton(buttonTitle: "Sign Up", size: geometry.size)
                                        }
                                        .buttonStyle(CustomButtonStyle(backgroundColor: .probabilityText))
                                        
                                        HStack {
                                            Text("Already have an account? ")
                                                .font(.system(.callout, design: .serif))
                                                .foregroundStyle(.white)
                                                .fontWeight(.ultraLight)
                                            
                                            if !isPresentedFromLoginView {
                                                
                                                NavigationLink(destination: SignUpPage(isPresentedFromLoginView: true)) {
                                                    Text("Login")
                                                        .font(.system(.title3, design: .serif))
                                                        .underline()
                                                        .foregroundStyle(Color.probabilityText)
                                                        .fontWeight(.semibold)
                                                    
                                                }
                                            } else {
                                                Text("Login")
                                                    .font(.system(.title3, design: .serif))
                                                    .underline()
                                                    .foregroundStyle(Color.probabilityText)
                                                    .fontWeight(.semibold)
                                                    .onTapGesture {
                                                        self.presentationMode.wrappedValue.dismiss()
                                                    }
                                            }
                                            
                                            
                                        }
                                        .frame(width: geometry.size.width * 0.8)
                                    }
                                    .frame(width: geometry.size.width, height: geometry.size.height * 0.15)
                                }
                                
                            }
                            .padding()
                            .frame(width: geometry.size.width, height: geometry.size.height * 0.8)
                            
                            Spacer()
                            
                            
                        }
                        .padding()
                        .frame(width: geometry.size.width, height: geometry.size.height)
                       
                        
                    }
                    .scrollDisabled(!isKeyboardVisible)
                    
                }
                
            }
            .gesture(
                TapGesture()
                    .onEnded { _ in
                        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
                    }
            )
            .fullScreenCover(isPresented: $showHomePage) {
    
                HomeView()
            }
        }
        .navigationBarBackButtonHidden(true)
        
    }
}

extension SignUpPage: AuthenticationOnRegexForTheUsersInputs {
    var isValidField: Bool {
        return !email.isEmpty &&
               !userName.isEmpty &&
               !password.isEmpty &&
               password == confirmPassword &&
               RegexFoundation.checkRegexPattern(pattern: RegexFoundation.emailRegex, stringToCheck: email) &&
        RegexFoundation.checkRegexPattern(pattern: RegexFoundation.passwordRegex, stringToCheck: password)
    }
}

#Preview {
    SignUpPage(isPresentedFromLoginView: false)
}

