//
//  TableViewTasksCell.swift
//  ZenTask
//
//  Created by gokul-zstch1317 on 29/04/24.
//

import UIKit

class TableViewTasksCell: UITableViewCell {
    
    static let reuseIdentifier = "TableViewTaskCell"
    
    let label = UILabel()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        addSubview(label)
        setConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setConstraints() {
        label.textColor = .black
        label.font = UIFont.systemFont(ofSize: 20)
        label.clipsToBounds = true
        label.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            label.centerXAnchor.constraint(equalTo: centerXAnchor),
            label.centerYAnchor.constraint(equalTo: centerYAnchor)
        ])
    }
    
    func setLabel(text: String){
        label.text = text
    }
}
