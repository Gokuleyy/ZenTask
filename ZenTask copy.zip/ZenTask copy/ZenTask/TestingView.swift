//
//  TestingView.swift
//  ZenTask
//
//  Created by gokul-zstch1317 on 02/05/24.
//

import SwiftUI

struct ScrollTestView: View {
    var body: some View {
        GeometryReader { geometry in
            VStack {
                Image(.facebookLogo)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: geometry.size.width / 2)
                
                Spacer()
                
                Image(.googleLogo)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: geometry.size.width / 2)
            }
        }
    }
}



#Preview {
    PasswordField1(password: .constant("eAe2@d"))
}

struct PasswordField: View {
    @Binding var password: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            SecureField("Password", text: $password)
                .textFieldStyle(RoundedBorderTextFieldStyle())
            
            Text("Password Strength:")
                .foregroundColor(.secondary)
            
            HStack {
                Text("At least 8 characters")
                    .foregroundColor(password.count >= 8 ? .green : .red)
                Spacer()
                Text("At least 1 uppercase")
                    .foregroundColor(password.contains { $0.isUppercase } ? .green : .red)
                Spacer()
                Text("At least 1 lowercase")
                    .foregroundColor(password.contains { $0.isLowercase } ? .green : .red)
                Spacer()
                Text("At least 1 digit")
                    .foregroundColor(password.contains { $0.isNumber } ? .green : .red)
                Spacer()
                Text("At least 1 special character")
                    .foregroundColor(password.rangeOfCharacter(from: .punctuationCharacters) != nil ? .green : .red)
            }
        }
        .padding()
    }
}

struct PasswordField1: View {
    
    @Binding var password: String
    @State var correForm: Bool = false
    
    var body: some View {
        HStack {
            
            Image(systemName: correForm ? "checkmark.circle.fill" : "xmark.circle.fill")
                .foregroundStyle(correForm ? .green : .logoColor1)
            
            Group {
               if !password.contains(where: { $0.isUppercase }) {
                   withAnimation {
                       Text("At least 1 uppercase")
                           .foregroundColor(.logoColor1)
                           .font(.caption)
                           .onAppear {
                               correForm = false
                           }
                   }
                } else if !password.contains(where: { $0.isLowercase }) {
                    withAnimation {
                        Text("At least 1 lowercase")
                            .foregroundColor(.logoColor1)
                            .font(.caption)
                            .onAppear {
                                correForm = false
                            }
                    }
                } else if !password.contains(where: { $0.isNumber }) {
                    withAnimation {
                        Text("At least 1 digit")
                            .foregroundColor(.logoColor1)
                            .font(.caption)
                            .onAppear {
                                correForm = false
                            }
                    }
                } else if password.rangeOfCharacter(from: .punctuationCharacters) == nil {
                    withAnimation {
                        Text("At least 1 special character")
                            .foregroundStyle(.logoColor1)
                            .font(.caption)
                            .onAppear {
                                correForm = false
                            }
                    }
                } else if password.count < 6 {
                    
                    withAnimation {
                        Text("At least length 6 characters")
                            .foregroundStyle(.logoColor1)
                            .font(.caption)
                            .onAppear {
                                correForm = false
                            }
                    }
                } else {
                    withAnimation {
                        Text("Password is strong")
                            .foregroundStyle(.green)
                            .font(.caption)
                            .onAppear {
                                correForm = true
                            }
                    }
                }
            }
            
            Spacer()
        }
        .padding()
    }
}

