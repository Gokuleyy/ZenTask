//
//  ViewControllerFilesIntoSwiftUI.swift
//  ZenTask
//
//  Created by gokul-zstch1317 on 15/04/24.
//

import SwiftUI

struct TodoListView: UIViewControllerRepresentable {
    typealias UIViewControllerType = UINavigationController
    
    @EnvironmentObject var viewModel: UsersViewModel
    
    
    func makeUIViewController(context: Context) -> UINavigationController {
        let todoViewController = TodoListViewController()
        todoViewController.viewModel = viewModel
        let navigationController = UINavigationController(rootViewController: todoViewController)
        return navigationController
    }
    func updateUIViewController(_ uiViewController: UINavigationController, context: Context) {
        
    }
}








