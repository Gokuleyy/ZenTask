//
//  AddTaskViewController.swift
//  ZenTask
//
//  Created by gokul-zstch1317 on 30/04/24.
//

import Foundation
import UIKit


class AddTaskViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .background1
        setUpConstraints()
    }
    
    private let pageTitleAddTask: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textColor = .black
        label.font = UIFont.preferredFont(forTextStyle: .title1)
        label.textColor = .white
        label.text = "Add Task"
        return label
    }()
    
    
    private let taskTitleLabel: UILabel = {
        let label = UILabel()
        label.text = "Task Title"
        label.font = UIFont.preferredFont(forTextStyle: .title3)
        label.textColor = .white
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let taskDescLabel: UILabel = {
        let label = UILabel()
        label.text = "Task Description"
        label.font = UIFont.preferredFont(forTextStyle: .title3)
        label.textColor = .white
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let taskDueDateLabel: UILabel = {
        let label = UILabel()
        label.text = "Due Date"
        label.font = UIFont.preferredFont(forTextStyle: .title3)
        label.textColor = .white
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let taskTitleField: UITextField = {
        let textField = UITextField()
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.clipsToBounds = true
        textField.placeholder = "Ex: Go to GYM"
        textField.borderStyle = .roundedRect
        return textField
    }()
    
    private let taskDescField: UITextField = {
        let textField = UITextField()
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.clipsToBounds = true
        textField.placeholder = "Ex: Do these following workouts..."
        textField.textAlignment = .justified
        textField.borderStyle = .roundedRect
        return textField
    }()
    
    private let dueDatePicker: UIDatePicker = {
        let datePicker = UIDatePicker()
        datePicker.datePickerMode = .date
        datePicker.translatesAutoresizingMaskIntoConstraints = false
        datePicker.tintColor = .background1
        datePicker.backgroundColor = .white
        return datePicker
    }()
    
    func setUpConstraints() {
        view.addSubview(pageTitleAddTask)
        view.addSubview(taskTitleLabel)
        view.addSubview(taskTitleField)
        view.addSubview(taskDescLabel)
        view.addSubview(taskDescField)
        view.addSubview(taskDueDateLabel)
        view.addSubview(dueDatePicker)
        
        
        
        NSLayoutConstraint.activate([
            pageTitleAddTask.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            pageTitleAddTask.topAnchor.constraint(equalTo: view.topAnchor, constant: 20),
            
            taskTitleLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 25),
            taskTitleLabel.topAnchor.constraint(equalTo: pageTitleAddTask.bottomAnchor, constant: 50),
            
            taskTitleField.topAnchor.constraint(equalTo: taskTitleLabel.bottomAnchor, constant: 20),
            taskTitleField.leadingAnchor.constraint(equalTo: taskTitleLabel.leadingAnchor),
            taskTitleField.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -30),
            taskTitleField.heightAnchor.constraint(equalToConstant: 50),
            
            taskDescLabel.topAnchor.constraint(equalTo: taskTitleField.bottomAnchor, constant: 40),
            taskDescLabel.leadingAnchor.constraint(equalTo: taskTitleField.leadingAnchor),
            
            
            taskDescField.topAnchor.constraint(equalTo: taskDescLabel.bottomAnchor, constant: 20),
            taskDescField.leadingAnchor.constraint(equalTo: taskTitleLabel.leadingAnchor),
            taskDescField.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -30),
            taskDescField.heightAnchor.constraint(equalToConstant: 150),
            
            taskDueDateLabel.topAnchor.constraint(equalTo: taskDescField.bottomAnchor, constant: 40),
            taskDueDateLabel.leadingAnchor.constraint(equalTo: taskDescField.leadingAnchor),
            
            dueDatePicker.centerYAnchor.constraint(equalTo: taskDueDateLabel.centerYAnchor),
            dueDatePicker.trailingAnchor.constraint(equalTo: taskDescField.trailingAnchor)
            
        ])
    }
}
