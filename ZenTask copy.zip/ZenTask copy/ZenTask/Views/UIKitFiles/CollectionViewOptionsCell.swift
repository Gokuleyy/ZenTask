//
//  OptionsHeaderCell.swift
//  ZenTask
//
//  Created by gokul-zstch1317 on 17/04/24.
//

import UIKit

class CollectionViewOptionsCell: UICollectionViewCell {
    static let reuseIdentifier: String = "OptionsCell"
    
    var selectedCell: String = "Completed"
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setLabelsAndAddUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private let headingLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont.systemFont(ofSize: 18)
        label.adjustsFontSizeToFitWidth = true
        return label
    }()
    
    func setLabelsAndAddUI(){
        addSubview(headingLabel)
        
        NSLayoutConstraint.activate([
            headingLabel.centerXAnchor.constraint(equalTo: centerXAnchor),
            headingLabel.centerYAnchor.constraint(equalTo: centerYAnchor)
        ])
    }
    
    func setLabelHeading(heading: String) {
        self.headingLabel.text = heading
    }
    
    func didSelectCell(selectedCell: String){
    }
}

