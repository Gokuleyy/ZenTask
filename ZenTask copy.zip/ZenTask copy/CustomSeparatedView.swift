//
//  CustomSeparatedView.swift
//  ZenTask
//
//  Created by gokul-zstch1317 on 10/05/24.
//

import SwiftUI

#Preview {
    TextFieldInputView(fieldName: "Email", fieldVariable: .constant(""), isPasswordField: false, isFromLoginView: false, isRightViewNeeded: true, size: CGSize())
}

struct RoundedCorners: Shape {
    var radius: CGFloat = .infinity
    var corners: UIRectCorner = .allCorners
    
    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(
            roundedRect: rect,
            byRoundingCorners: corners,
            cornerRadii: CGSize(width: radius, height: radius)
        )
        return Path(path.cgPath)
    }
}

struct TextFieldInputView: View {
    
    @State var fieldName: String
    @Binding var fieldVariable: String
    @State private var isViewPassword: Bool = false
    @State var isPasswordField: Bool
    @FocusState var isFocusedField: Bool
    @State var isFromLoginView: Bool
    @State var isRightViewNeeded: Bool = false
    @State var size: CGSize
    
    private var isEmailEmpty: Bool { fieldVariable.isEmpty }
    private var isPasswordEmpty: Bool { fieldVariable.isEmpty }
    private var isCorrectPatternEmail: Bool { RegexFoundation.checkRegexPattern(pattern: RegexFoundation.emailRegex, stringToCheck: fieldVariable) }
    
    private var isCorrectPatternPassword: Bool { RegexFoundation.checkRegexPattern(pattern: RegexFoundation.passwordRegex, stringToCheck: fieldVariable) }
    
    

    var body: some View {
        VStack(alignment: .leading) {
            Text(fieldName)
                .font(.system(size: 15, weight: .medium, design: .serif))
                .foregroundStyle(Color.background1)
                .controlSize(.small)
            
            if isPasswordField {
                VStack {
                    HStack {
                        if isViewPassword {
                            TextField("Enter your password", text: $fieldVariable)
                        } else {
                            SecureField("Enter your password", text: $fieldVariable)
                            
                        }
                        Spacer()
                        
                        if isRightViewNeeded {
                            Image(systemName: isViewPassword ? "eye" : "eye.slash")
                                .foregroundColor(Color.white)
                                .onTapGesture {
                                    isViewPassword.toggle()
                                }
                                .padding(.trailing, 10)
                        }
                    }
                    .padding(.leading, 15)
                    .frame(height: size.height * 0.05)
                    .background(Color.background1)
                    .cornerRadius(10)
                    .foregroundColor(Color.white)
                }
                
                if !isPasswordEmpty && isFromLoginView {
                    Text("Password must contain an upper, lower, numeric, special character and minimum length is 6")
                        .foregroundStyle(Color.red)
                        .font(.footnote)
                        .multilineTextAlignment(.leading)
                        .lineLimit(2, reservesSpace: true)
                        .controlSize(.mini)
                        .opacity(isCorrectPatternPassword ? 0 : 1)
                }
            }
            else {
                TextField("Enter your username", text: $fieldVariable)
                    .focused($isFocusedField)
                    .padding(.leading, 15)
                    .frame(height: size.height * 0.05)
                    .background(Color.background1)
                    .cornerRadius(10)
                    .foregroundStyle(Color.white)
                    .textInputAutocapitalization(.never)
                    .overlay(
                        Image(systemName: isEmailEmpty ? "" : "xmark.circle.fill")
                            .foregroundColor(.white)
                            .padding(.trailing, 15)
                            .font(.system(size: 15))
                            .onTapGesture {
                                self.fieldVariable = ""
                            }
                            .opacity(isEmailEmpty ? 0 : 1),
                        alignment: .trailing
                    )
                if !isPasswordEmpty && isFromLoginView {
                    Text("Please enter a valid email address")
                        .foregroundStyle(Color.red)
                        .font(.footnote)
                        .multilineTextAlignment(.leading)
                        .lineLimit(2, reservesSpace: true)
                        .opacity(isCorrectPatternEmail ? 0 : 1)
                }
            }
        }
    }
}

struct CustomisedButton: View {
    
    @State var buttonTitle: String
    var size: CGSize
    
    var body: some View {
        Text(buttonTitle)
            .font(.system(.title2, design: .serif))
            .fontWeight(.semibold)
            .foregroundStyle(Color.background1)
            .frame(width: size.width * 0.8, height: size.height * 0.06)
            .frame(minHeight: 40)
            .background(Color.probabilityText)
            .clipShape(RoundedRectangle(cornerRadius: 10))
        
    }
}

struct CustomButtonStyle: ButtonStyle {
    
    @State var backgroundColor: Color
    
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .background(
                RoundedRectangle(cornerRadius: 10)
                    .fill(backgroundColor)
            )
            .scaleEffect(configuration.isPressed ? 0.97 : 1)
            .animation(.easeInOut, value: 0.1)
    }
}

struct CustomTextField: View {
    
   @Binding var text: String
    var isPassword: Bool
    var placeholder: String
    var size: CGSize
    @FocusState var focusedField: Bool
    
    

    var body: some View {
        
        VStack {
            
            if isPassword {
                SecureField(text: $text) {
                    Text(placeholder)
                        .font(.system(.headline, design: .serif))
                        .fontWeight(.light)
                        .foregroundStyle(.gray)
                        .kerning(0.7)
                }
                .font(.system(.callout, design: .serif))
                .padding(.bottom, 5)
                .frame(width: size.width * 0.8, height: size.height * 0.06)
                .foregroundStyle(.white)
                .overlay (
                    Rectangle()
                        .frame(height: 2)
                        .foregroundStyle(.white),
                    alignment: .bottom
                )
                .textInputAutocapitalization(.never)
            } else {
                TextField(text: $text) {
                    Text(placeholder)
                        .font(.system(.headline, design: .serif))
                        .fontWeight(.light)
                        .foregroundStyle(.gray)
                        .kerning(0.7)
                }
                .font(.system(.callout, design: .serif))
                .focused($focusedField)
                .padding(.bottom, 10)
                .frame(width: size.width * 0.8, height: size.height * 0.06)
                .foregroundStyle(.white)
                .overlay (
                    Rectangle()
                        .frame(height: 2)
                        .foregroundStyle(.white),
                    alignment: .bottom
                )
                .textInputAutocapitalization(.never)
            }
        }
        .padding()
        .frame(width: size.width * 0.8, height: size.height * 0.1)
    }
}





