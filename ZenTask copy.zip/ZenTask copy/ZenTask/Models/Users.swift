//
//  Users.swift
//  ZenTask
//
//  Created by gokul-zstch1317 on 25/04/24.
//

import Foundation


struct Users: Identifiable, Codable {
    
    var id: String
    var userName: String
    var email: String
    var tasks: [UsersTask]?
    var moods: [UsersMood]?
    var password: String?
    
    var initials: String {
        let formatter = PersonNameComponentsFormatter()
        if let components = formatter.personNameComponents(from: userName) {
            formatter.style = .abbreviated
            return formatter.string(from: components)
        }
        return ""
    }
    
    mutating func setPassword(password: String) {
        self.password = RegexFoundation.hashPassword(password: password)
    }
    
    func getPassword(passwordToCheck: String) -> Bool {
        
        return self.password == RegexFoundation.hashPassword(password: passwordToCheck)
    }
}


struct UsersTask: Codable, Hashable {
    var taskID = UUID()
    let taskTitle: String
    let taskDescription: String?
    let taskPriority: PriorityTask.RawValue
    let dueDate: Date?
}

enum PriorityTask: String, Codable {
    case high = "HIGH"
    case medium = "MEDIUM"
    case low = "LOW"
}
struct UsersMood: Codable {
    
}

extension Users {
    static var sample_user = Users(id: NSUUID().uuidString, userName: "Gokuleyy", email: "1234@gmail.com")
}
